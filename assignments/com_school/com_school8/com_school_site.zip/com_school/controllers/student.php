<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * HelloWorld Controller
 *
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 * @since       0.0.9
 */
class SchoolControllerStudent extends JControllerForm
{
	public function cancel($key = null)
	{
		//parent::cancel($key);
        $url="https://localhost/news_cms/index.php/component/school/";
		// set up the redirect back to the same form
		$this->setRedirect(
			$url,
			JText::_(COM_SCHOOL_CANCELLED)
			);
	}
	/*
	 * Function handing the save for adding a new helloworld record
	 * Based on the save() function in the JControllerForm class
	 */
	public function save($key = null, $urlVar = null)
	{
		// Check for request forgeries.
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));
		$app = JFactory::getApplication();
		$input = $app->input;
		$model = $this->getModel('studentform');
		$currentUri = (string)JUri::getInstance();
		$input = JFactory::getApplication()->input;
		//$post_array = $input->getArray($_POST);
		//print_r($post_array);
		//$data=$post_array['jform'];
		//print_r($data);
		$data  = $input->get('jform', array(), 'array');
		// print_r($data);
		
		//$fileinfo = $this->input->files->get('jform', array(), 'array');		// print_r($fileinfo);
		// $mediaparams = JComponentHelper::getParams('com_media');
		// 	$relativePathname = JPath::clean($mediaparams->get($path, 'images'));
		// 	$absolutePathname = JPATH_ROOT . '/' . $relativePathname;
		$fileinfo = $this->input->files->get('jform', array(), 'array');
		$data = $model->save($data,$fileinfo);


    }

}
