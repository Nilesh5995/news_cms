<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * HelloWorld Controller
 *
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 * @since       0.0.9
 */
class SchoolControllerTeacher extends JControllerForm
{
	public function save($key = null, $urlVar = null)
	{
		// Check for request forgeries.
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));
		$app = JFactory::getApplication();
		$input = $app->input;
		$model = $this->getModel('teacherform');
		$currentUri = (string)JUri::getInstance();
		$input = JFactory::getApplication()->input;
		$data  = $input->get('jform', array(), 'array');
		$fileinfo = $this->input->files->get('jform', array(), 'array');
		$data = $model->save($data,$fileinfo);


    }
}