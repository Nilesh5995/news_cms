<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_articles_category
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
/**
	* Helper for mod_articles_category
	*
	* @since  1.6
	*/
class ModArticleHelper
{
	/**
	 * Get a list of articles from a specific category
	 *
	 * @param   \Joomla\Registry\Registry  $count  object holding the models parameters
	 *
	 * @return  mixed
	 *
	 * @since  1.6
	 */

	public static function ShowTitle($count)
	{
	/**
	 * Method to showing the article based on count
	 *
	 * The goal is to get the proper articlebased on the count.
	 *
	 * @param   int   $count  The number of the count  to show article
	 * @return  array  The array of article
	 *
	 * @since   1.6
	 * 
	 */
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('*')
		->from('#__content')
		->order('id DESC');
		$db->setQuery($query, 0, $count);
		$rows = $db->loadObjectList();
		$arr = [];

		foreach ( $rows as $row)

			{
				$lang = (explode("-", $row->language));

				$arr[] = array("$row->title" => $lang[0]);
		}

		return (array) $arr;
	}

	/**
	 * Method to show the subtype of the article
	 *
	 * The goal is to show the categories of the article
	 *
	 * @param   int  $articleId  the id of the article
	 * 
	 * @return  object  The categories of the article
	 *
	 * @since   1.6
	 * 
	 */
	public static function  getCategoryName($articleId)
	{
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('c.title');
		$query->from('#__categories AS c');
		$query->join("INNER", "#__content AS a ON c.id = a.catid");
		$query->where("a.id = '$articleId'");
		$db->setQuery($query);
		$row = $db->loadObject();

			return $row->title;
	}

	/**
	 * Method to change tha layout
	 *
	 * The goal is to get the proper layput of the the mdule.
	 * the html intact as possible with all tags properly closed.
	 *
	 * @param   string  $direction  The direction of the layout
	 * 
	 * @return  string  layout direction
	 *
	 * @since   1.6
	 * 
	 */
	public static function SetDirection($direction)
	{
		// First get the plain text string. This is the rendered text we want to end up with.
		// $mode = $params->get('position', 'left');

		return $direction;
	}
}
